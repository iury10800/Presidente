# 🗳️ President Simulator
Um simples simulador político feito em React.
Criado por **Iury**.