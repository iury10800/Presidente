import React, { useState } from 'react';
import { AlertCircle, TrendingUp, TrendingDown, Users, DollarSign, Heart, Shield, Globe } from 'lucide-react';

export default function App() {
  const [approval, setApproval] = useState(50);
  const [economy, setEconomy] = useState(1000);
  const [population, setPopulation] = useState(1000000);

  const handleDecision = (impact) => {
    setApproval(Math.max(0, Math.min(100, approval + impact.approval)));
    setEconomy(economy + impact.economy);
    setPopulation(population + impact.population);
  };

  const decisions = [
    { title: "Aumentar impostos", approval: -10, economy: 200, population: -5000 },
    { title: "Investir em saúde", approval: +15, economy: -300, population: +10000 },
    { title: "Criar programa social", approval: +10, economy: -200, population: +5000 },
    { title: "Reduzir gastos militares", approval: +5, economy: 150, population: 0 }
  ];

  return (
    <div style={{ padding: 20, fontFamily: "Arial, sans-serif", background: "#0f172a", color: "white", minHeight: "100vh" }}>
      <h1 style={{ textAlign: "center" }}>🗳️ President Simulator</h1>
      <p style={{ textAlign: "center" }}>Aprovação: {approval}% | Economia: ${economy} | População: {population.toLocaleString()}</p>

      <div style={{ display: "flex", flexWrap: "wrap", gap: 10, justifyContent: "center", marginTop: 30 }}>
        {decisions.map((d, i) => (
          <button
            key={i}
            onClick={() => handleDecision(d)}
            style={{
              background: "#1e293b",
              border: "1px solid #334155",
              borderRadius: 10,
              padding: "10px 20px",
              cursor: "pointer",
              color: "white"
            }}
          >
            {d.title}
          </button>
        ))}
      </div>
    </div>
  );
}